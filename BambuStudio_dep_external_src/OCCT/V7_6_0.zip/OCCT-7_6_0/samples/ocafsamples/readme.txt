========================================================================
       Open CasCade Application Framework samples
========================================================================


The provided in this directory set of samples dedicated to get initial 
knowledge about typical actions with OCAF services. 
All samples are compilable, but the method 'Sample()' of each file is not
dedicated for execution 'as is'. Rather it can be considered as set of 
logical actions using some OCAF service. It may be useful for newcomers.

