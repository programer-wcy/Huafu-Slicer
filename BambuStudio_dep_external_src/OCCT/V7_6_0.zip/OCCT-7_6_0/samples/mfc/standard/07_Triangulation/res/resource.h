//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by TopologyTriangulation.rc
//
#define ID_BOX                          802
#define ID_Cylinder                     803
#define ID_TRIANGU                      804
#define ID_Clear                        805
#define ID_Visu                         806
#define ID_BUTTONPrev                   807
#define ID_BUTTONRepeat                 808
#define ID_BUTTONStart                  809
#define ID_BUTTONNext                   810
#define ID_BUTTONEnd                    811
#define ID_BUTTON812                    812
#define ID_DUMP_VIEW                    812

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         813
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
