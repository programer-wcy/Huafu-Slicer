#!/bin/bash
#Define QTDIR variables in order to generate Makefile files by qmake
export QTDIR=
