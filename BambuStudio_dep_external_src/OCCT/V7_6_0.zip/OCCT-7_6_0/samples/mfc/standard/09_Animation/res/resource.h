//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Animation.rc
//
#define IDR_SAMPLE3DTYPE                131
#define IDD_SENS                        131
#define IDD_TUNE                        132
#define IDD_ShadingBoxDialog            170
#define IDD_ThreadBoxDialog             171
#define ID_BUTTONFly                    804
#define ID_BUTTONTurn                   805
#define IDC_FLY                         1002
#define IDC_SPIN1                       1003
#define IDC_TURN                        1004
#define IDC_SPIN2                       1005
#define IDC_FOCDIST                     1005
#define IDC_SPINANG                     1006
#define IDC_APPERTURE                   1007
#define IDC_SPINFOC                     1008
#define IDC_XEYE                        1009
#define IDC_YEYE                        1010
#define IDC_ZEYE                        1011
#define IDC_XAT                         1012
#define IDC_YAT                         1013
#define IDC_ZAT                         1014
#define IDC_TWIST                       1015
#define ID_OBJECT_MATERIAL              1205
#define ID_OBJECT_TRANPARENCY           1214
#define IDC_SLIDER1                     1500
#define IDC_Angle                       1502
#define IDC_FSaveSTEP_Type              3002
#define ID_ANIMATION                    32790
#define ID_STOP                         32792
#define ID_RESTART                      32793
#define ID_SHADING                      32794
#define ID_Thread                       32795
#define ID_DESTRUCT                     32796
#define ID_FILE_LOADGRID                32798
#define ID_VIEW_DISPLAYSTATUS           32800
#define ID_WALK_WALKTHRU                32801
#define ID_WALK_SENSITIVITY             32802
#define ID_WALK_WALKTHROUGH             32803
#define ID_WALK_THROUGH                 32804
#define ID_SENSITIVITY                  32805

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        174
#define _APS_NEXT_COMMAND_VALUE         32806
#define _APS_NEXT_CONTROL_VALUE         1503
#define _APS_NEXT_SYMED_VALUE           170
#endif
#endif
