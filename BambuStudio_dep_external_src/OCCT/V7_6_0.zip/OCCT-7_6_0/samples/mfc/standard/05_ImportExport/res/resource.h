//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ImportExport.rc
//
#define ID_FILE_OPEN32803               32803
#define ID_BOX                          32804
#define ID_Cylinder                     32806
#define ID_FILE_OPEN32807               32807
#define ID_FILE_SAVEAS                  32808
#define ID_FILE_SAVE32809               32809
#define ID_FILE_RECENTFILE              32810
#define ID_FILE_EXPORT_STL              32896
#define ID_FILE_EXPORT_VRML             32897

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        178
#define _APS_NEXT_COMMAND_VALUE         32811
#define _APS_NEXT_CONTROL_VALUE         1505
#define _APS_NEXT_SYMED_VALUE           170
#endif
#endif
