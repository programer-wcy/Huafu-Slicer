//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Ocaf.rc
//
#define IDR_ACTIONS                     500
#define IDR_UNDOREDO                    520
#define IDD_NEWBOX                      529
#define IDD_NEWCYL                      530
#define ID_WINDOW_NEW3D                 1151
#define ID_OBJECT_DELETE                1202
#define IDC_R                           1650
#define IDC_X                           1659
#define IDC_L                           1660
#define IDC_Y                           1663
#define IDC_Z                           1664
#define IDC_H                           1665
#define IDC_W                           1666
#define IDC_NAME                        1673
#define ID_CREATEBOX                    3000
#define ID_CUT                          3002
#define ID_CREATECYL                    3003
#define ID_MODIFY                       3004
//#define ID_DFBR                         3007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        504
#define _APS_NEXT_COMMAND_VALUE         3007
#define _APS_NEXT_CONTROL_VALUE         1658
#define _APS_NEXT_SYMED_VALUE           600
#endif
#endif
