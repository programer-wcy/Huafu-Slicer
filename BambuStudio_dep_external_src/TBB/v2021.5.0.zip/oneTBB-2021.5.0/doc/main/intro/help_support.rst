.. _help_support:

Getting Help and Support
========================





.. container:: section


   .. rubric:: Getting Technical Support
      :class: sectiontitle

   If you did not register your Intel® software product during
   installation, please do so now at the Intel® Software Development
   Products Registration Center. Registration entitles you to free
   technical support, product updates and upgrades for the duration of
   the support term.


   For general information about Intel technical support, product
   updates, user forums, FAQs, tips and tricks and other support
   questions, go to: http://www.intel.com/software/products/support/.

